import React, { useState } from 'react';
import { useGame } from './hooks/useGame';
import AnswerForm from './components/AnswerForm';
import FeedbackDisplay from './components/FeedbackDisplay';
import FinancialStatusModal from './components/FinancialStatusModal';
import LoadingSpinner from './components/LoadingSpinner';
import QuestionDisplay from './components/QuestionDisplay';
import ResultScreen from './components/ResultScreen';
import './App.css';

const LoginScreen = ({ onLogin, loading }) => {
    const [userIdInput, setUserIdInput] = useState('');
    const handleLogin = (e) => {
        e.preventDefault();
        if (userIdInput.trim()) {
            onLogin(userIdInput.trim());
        }
    };
    return (
        <div className="login-screen">
            <form onSubmit={handleLogin} className="login-form">
                <h2><img src="/logo.png" alt="Become Bezos Logo" className="app-logo"/></h2>
                <h2>"Become Bezos"</h2>
                <h3>「ビカム・ベゾス」は、あなたがジェフ・ベゾス氏の思考法と経営戦略を実践し、ゼロから世界企業を築く意思決定ゲームです。</h3>
                <p> 顧客への病的執着： 目先の利益より、顧客を「ワオ！」と驚かせる体験を追求せよ。</p>
                <p>長期的な視点： 短期的な損失を恐れず、5年、10年先を見据えた大胆な投資を行え。</p>
                <p>破壊的イノベーション： 既存の常識を打ち破り、新たなビジネスモデルを創造せよ。</p>
                <p>実験と高速学習： 失敗を恐れず、迅速に試行錯誤を繰り返し、成功への道を見つけ出せ。</p>
                <input
                    type="text"
                    value={userIdInput}
                    onChange={(e) => setUserIdInput(e.target.value)}
                    placeholder="会社名を入力"
                    className="login-input"
                />
                <button
                    type="submit"
                    className="login-button"
                    disabled={!userIdInput.trim() || loading}
                >
                    {loading ? '読込中...' : 'ゲーム開始 / 続行'}
                </button>
            </form>
        </div>
    );
};


function App() {
    const { userId, isLoading, error, gameState, allGameContexts, login, submitAnswer, handleNextQuestion } = useGame();
    const [isFinancialModalOpen, setIsFinancialModalOpen] = useState(false);

    if (error) {
        return <div className="error-message">エラー: {error}</div>;
    }

    if (!userId) {
        return <LoginScreen onLogin={login} loading={isLoading} />;
    }

    if (gameState.gameEnded && allGameContexts) {
        return (
            <ResultScreen
                history={{ answers: gameState.answerHistory }}
                finalFinancialData={gameState.financialData}
                financialDataHistory={gameState.financialDataHistory}
                allQuestions={allGameContexts}
            />
        );
    }

    if (isLoading || !gameState.currentContextData) {
        return <LoadingSpinner message="データをロード中..." />;
    }

    return (
        <div className="app-container">
            <header className="app-header">
                <h1><img src="/logo.png" alt="Become Bezos Logo" className="app-logo" width="150"/></h1>
            </header>
            <h1>事業戦略会議</h1>
            <p className="user-id-display" title={userId}>
                社名: {userId}
            </p>
            <button
                className="financial-status-button"
                onClick={() => setIsFinancialModalOpen(true)}
            >
                現在の財務状況を確認
            </button>

            {gameState.isWaitingForHost ? (
                <LoadingSpinner />
            ) : (
                <>
                    {gameState.feedback ? (
                        <FeedbackDisplay
                            feedback={gameState.feedback}
                            onNextQuestion={handleNextQuestion}
                            gameEnded={gameState.gameEnded}
                            financialImpact={gameState.latestFinancialImpactApplied}
                        />
                    ) : (
                        <div key={gameState.currentContextData.id}>
                            <QuestionDisplay question={gameState.currentContextData} />
                            <AnswerForm onSubmit={submitAnswer} options={gameState.currentContextData.options} />
                        </div>
                    )}
                </>
            )}

            {isFinancialModalOpen && (
                <FinancialStatusModal
                    isOpen={isFinancialModalOpen}
                    onClose={() => setIsFinancialModalOpen(false)}
                    financialData={gameState.financialData}
                />
            )}
        </div>
    );
}

export default App;