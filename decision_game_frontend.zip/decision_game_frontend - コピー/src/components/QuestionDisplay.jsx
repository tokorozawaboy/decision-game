import React from 'react';
import './QuestionDisplay.css';

const QuestionDisplay = ({ question }) => (
    <div className="question-display-container">
        <h2>次の意思決定を行ってください</h2>
        {/* <p>現在の局面ID: {question.id}</p> */}
        <p>段階: {question.stage}</p>
        </div>
);

export default QuestionDisplay;