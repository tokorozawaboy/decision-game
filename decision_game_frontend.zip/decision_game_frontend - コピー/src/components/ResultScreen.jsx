import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import LoadingSpinner from './LoadingSpinner';
import './ResultScreen.css';

// 数値を読みやすい形式（3桁区切り）にフォーマットする関数
const formatNumber = (num) => num.toLocaleString();

// 増減額に応じてCSSクラス名を返す関数
const getChangeColor = (change) => {
    if (change > 0) return 'positive';
    if (change < 0) return 'negative';
    return '';
};

// 財務諸表の行を生成する共通コンポーネント
const FinancialStatementRow = ({ label, startValue, endValue, isBold = false, isSub = false, isTotal = false }) => {
    const change = endValue - startValue;
    const changeColor = getChangeColor(change);
    
    // クラス名を動的に結合
    const rowClass = `financial-table-row ${isTotal ? 'total-row' : ''}`;
    const labelClass = `label ${isSub ? 'sub-item' : ''} ${isBold ? 'bold' : ''}`;
    const valueClass = `value ${isBold ? 'bold' : ''}`;
    const changeClass = `change ${changeColor}`;

    return (
        <tr className={rowClass}>
            <td className={labelClass}>{label}</td>
            <td className="value">{formatNumber(startValue)}</td>
            <td className={valueClass}>{formatNumber(endValue)}</td>
            <td className={changeClass}>
                {change > 0 ? '+' : ''}{formatNumber(change)}
            </td>
        </tr>
    );
};


const ResultScreen = ({ history, finalFinancialData, financialDataHistory, allQuestions }) => {

    if (!allQuestions || !history?.answers || !financialDataHistory || financialDataHistory.length === 0) {
        return <LoadingSpinner message="結果を集計中..." />;
    }

    const initialFinancialData = financialDataHistory[0];

    // ヘルパー関数: 選択肢IDからテキストを取得
    const getOptionTextById = (contextPath, optionId) => {
        const context = allQuestions[contextPath];
        if (context && context.options) {
            const option = context.options.find(opt => opt.id === optionId);
            return option ? option.text : `不明な選択 (${optionId})`;
        }
        return `不明な選択 (${optionId})`;
    };

    const generateChartData = () => {
        const labels = ['開始時'];
        history.answers.forEach(answer => {
            // answer.selectedOptionText が存在すればそれを優先
            // なければ answer.selectedOptionId と allQuestions を使ってテキストを探す
            labels.push(answer.selectedOptionText || getOptionTextById(answer.contextPath, answer.selectedOptionId));
        });

        return financialDataHistory.map((dataPoint, index) => ({
            name: labels[index] || `段階 ${index}`,
            '純利益': dataPoint.netIncome,
            '総資産': dataPoint.totalAssets,
        }));
    };

    const chartData = generateChartData();

    // 純利益と総資産の最小値と最大値を計算
    const netIncomeValues = chartData.map(d => d['純利益']);
    const minNetIncome = Math.min(...netIncomeValues);
    const maxNetIncome = Math.max(...netIncomeValues);

    const totalAssetsValues = chartData.map(d => d['総資産']);
    const minTotalAssets = Math.min(...totalAssetsValues);
    const maxTotalAssets = Math.max(...totalAssetsValues);

    // Y軸の表示範囲に少し余裕を持たせるためのバッファ計算とゼロラインの明確化
    // 純利益（マイナスもあり得る）
    const netIncomeRange = maxNetIncome - minNetIncome;
    let netIncomeDomainMin = minNetIncome - netIncomeRange * 0.1; // 最小値から10%下へ
    const netIncomeDomainMax = maxNetIncome + netIncomeRange * 0.1; // 最大値から10%上へ

    // 純利益がプラスとマイナスをまたぐ場合、Y軸の最小値を0以下に設定し、ゼロラインを明確にする
    if (minNetIncome < 0 && maxNetIncome > 0) {
        netIncomeDomainMin = Math.min(0, netIncomeDomainMin); // 0をまたぐ場合は、0以下で最小値を設定
    } else if (minNetIncome >= 0 && netIncomeDomainMin < 0) {
        netIncomeDomainMin = 0; // データが常にプラスだが、バッファでマイナスになる場合は、0を最小値にする
    }
    // 総資産（通常はプラスのみ）
    const totalAssetsRange = maxTotalAssets - minTotalAssets;
    // 総資産のY軸の最小値は0、または計算したバッファ値を採用し、データが軸に近すぎないように調整
    const totalAssetsDomainMin = Math.max(0, minTotalAssets - totalAssetsRange * 0.1); 
    const totalAssetsDomainMax = maxTotalAssets + totalAssetsRange * 0.1;


    // グラフの数値を百万円単位にフォーマットする関数 (変更箇所)
    const formatNumberForChart = (num) => (num / 1_000_000).toLocaleString(undefined, { maximumFractionDigits: 0 }); // 小数点以下0桁まで表示


    return (
        <div className="result-screen-page">
            <div className="result-screen-container">
                <h2>結果</h2>

                <div className="result-card">
                    <h3 className="card-title">最終財務諸表</h3>
                    <div className="financial-statements-grid">
                        <div className="financial-table-wrapper">
                            <table className="financial-table">
                                <thead>
                                    <tr>
                                        <th>損益計算書 (P/L)</th>
                                        <th>開始時</th>
                                        <th>最終</th>
                                        <th>増減</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <FinancialStatementRow label="売上高" startValue={initialFinancialData.sales} endValue={finalFinancialData.sales} isBold />
                                    <FinancialStatementRow label="売上原価" startValue={initialFinancialData.costOfGoodsSold} endValue={finalFinancialData.costOfGoodsSold} isSub />
                                    <FinancialStatementRow label="売上総利益" startValue={initialFinancialData.grossProfitAmount} endValue={finalFinancialData.grossProfitAmount} isBold isTotal />
                                    <FinancialStatementRow label="販売費及び一般管理費" startValue={initialFinancialData.sga} endValue={finalFinancialData.sga} isSub />
                                    <FinancialStatementRow label="営業利益" startValue={initialFinancialData.operatingIncome} endValue={finalFinancialData.operatingIncome} isBold isTotal />
                                    <FinancialStatementRow label="営業外収益" startValue={initialFinancialData.nonOperatingIncome} endValue={finalFinancialData.nonOperatingIncome} isSub />
                                    <FinancialStatementRow label="営業外費用" startValue={initialFinancialData.nonOperatingExpenses} endValue={finalFinancialData.nonOperatingExpenses} isSub />
                                    <FinancialStatementRow label="経常利益" startValue={initialFinancialData.ordinaryIncome} endValue={finalFinancialData.ordinaryIncome} isBold isTotal />
                                    <FinancialStatementRow label="法人税等" startValue={initialFinancialData.corporateTax} endValue={finalFinancialData.corporateTax} isSub />
                                    <FinancialStatementRow label="当期純利益" startValue={initialFinancialData.netIncome} endValue={finalFinancialData.netIncome} isBold isTotal />
                                </tbody>
                            </table>
                        </div>
                        <div className="financial-table-wrapper">
                            <table className="financial-table">
                                <thead>
                                    <tr>
                                        <th>貸借対照表 (B/S)</th>
                                        <th>開始時</th>
                                        <th>最終</th>
                                        <th>増減</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <FinancialStatementRow label="流動資産" startValue={initialFinancialData.currentAssets} endValue={finalFinancialData.currentAssets} isSub />
                                    <FinancialStatementRow label="固定資産" startValue={initialFinancialData.fixedAssets} endValue={finalFinancialData.fixedAssets} isSub />
                                    <FinancialStatementRow label="資産合計" startValue={initialFinancialData.totalAssets} endValue={finalFinancialData.totalAssets} isBold isTotal />
                                    <FinancialStatementRow label="流動負債" startValue={initialFinancialData.currentLiabilities} endValue={finalFinancialData.currentLiabilities} isSub />
                                    <FinancialStatementRow label="固定負債" startValue={initialFinancialData.fixedLiabilities} endValue={finalFinancialData.fixedLiabilities} isSub />
                                    <FinancialStatementRow label="負債合計" startValue={initialFinancialData.totalLiabilities} endValue={finalFinancialData.totalLiabilities} isBold isTotal />
                                    <FinancialStatementRow label="純資産" startValue={initialFinancialData.netAssets} endValue={finalFinancialData.netAssets} isBold isTotal />
                                    <FinancialStatementRow label="負債・純資産合計" startValue={initialFinancialData.totalLiabilitiesAndNetAssets} endValue={finalFinancialData.totalLiabilitiesAndNetAssets} isBold isTotal />
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div className="result-card">
                    <h3 className="card-title">財務推移</h3>
                    <div className="chart-section">
                        <div className="chart-wrapper">
                            <h4>純利益の推移</h4>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" angle={-15} textAnchor="end" height={100} interval={0} />
                                    <YAxis
                                        label={{ value: '百万円', angle: -90, position: 'insideLeft' }}
                                        tickFormatter={(value) => formatNumberForChart(value)}
                                        tickCount={7}
                                        domain={[netIncomeDomainMin, netIncomeDomainMax]}
                                    />
                                    <Tooltip formatter={(value) => `${formatNumberForChart(value)}百万円`} />
                                    <Legend />
                                    <Line type="monotone" dataKey="純利益" stroke="#10b981" strokeWidth={2} activeDot={{ r: 8 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="chart-wrapper">
                            <h4>総資産の推移</h4>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" angle={-15} textAnchor="end" height={100} interval={0} />
                                    <YAxis
                                        label={{ value: '百万円', angle: -90, position: 'insideLeft' }}
                                        tickFormatter={(value) => formatNumberForChart(value)}
                                        tickCount={7}
                                        domain={[totalAssetsDomainMin, totalAssetsDomainMax]}
                                    />
                                    <Tooltip formatter={(value) => `${formatNumberForChart(value)}百万円`} />
                                    <Legend />
                                    <Line type="monotone" dataKey="総資産" stroke="#8b5cf6" strokeWidth={2} activeDot={{ r: 8 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div className="result-card">
                    <h3 className="card-title">意思決定の履歴</h3>
                    <div className="history-table-wrapper">
                        <table className="history-table">
                            <thead>
                                <tr>
                                    <th>段階</th>
                                    <th>選択した戦略</th>
                                    <th>理由</th>
                                    <th>評価</th>
                                </tr>
                            </thead>
                            <tbody>
                                {history.answers.map((answer, index) => {
                                    // まず answer.selectedOptionText を確認
                                    // なければ getOptionTextById を使って allQuestions から探す
                                    const selectedStrategyText = answer.selectedOptionText || getOptionTextById(answer.contextPath, answer.selectedOptionId);
                                    
                                    return (
                                        <tr key={index}>
                                            <td>{index + 1}</td>
                                            <td>{selectedStrategyText}</td>
                                            <td>{answer.reason}</td>
                                            <td>{answer.comment}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ResultScreen;