import React from 'react';
import './FeedbackDisplay.css';

const impactLabels = {
    salesChangeRate: { label: '売上変動率', unit: '%' },
    grossProfitRateChangePt: { label: '粗利率変動', unit: 'pt' },
    operatingIncomeChangeRate: { label: '営業利益変動率', unit: '%' },
    ordinaryIncomeRateChangePt: { label: '経常利益率変動', unit: 'pt' },
    netIncomeRateChangePt: { label: '純利益率変動', unit: 'pt' },
    currentAssetsRatioChangePt: { label: '流動資産比率変動', unit: 'pt' },
    fixedAssetsRatioChangePt: { label: '固定資産比率変動', unit: 'pt' },
    currentLiabilitiesRatioChangePt: { label: '流動負債比率変動', unit: 'pt' },
    fixedLiabilitiesRatioChangePt: { label: '固定負債比率変動', unit: 'pt' },
    netAssetsRatioChangePt: { label: '純資産比率変動', unit: 'pt' },
    notes: { label: '備考', unit: '' }
};

const plKeys = ['salesChangeRate', 'grossProfitRateChangePt', 'operatingIncomeChangeRate', 'ordinaryIncomeRateChangePt', 'netIncomeRateChangePt'];
const bsKeys = ['currentAssetsRatioChangePt', 'fixedAssetsRatioChangePt', 'currentLiabilitiesRatioChangePt', 'fixedLiabilitiesRatioChangePt', 'netAssetsRatioChangePt'];

const ImpactItem = ({ impactKey, value }) => {
    const { label, unit } = impactLabels[impactKey];
    const isPositive = value > 0;
    const isNegative = value < 0;

    let valueClassName = "impact-item-value";
    if (isPositive) {
        valueClassName += " positive";
    } else if (isNegative) {
        valueClassName += " negative";
    }

    return (
        <li className="impact-item">
            <span className="impact-item-label">{label}:</span>
            <span className={valueClassName}>
                {isPositive ? '+' : ''}{value}{unit}
            </span>
        </li>
    );
};

const FeedbackDisplay = ({ feedback, onNextQuestion, gameEnded, financialImpact }) => {
    
    const getImpacts = (keys) => financialImpact 
        ? keys.filter(key => financialImpact[key] !== undefined && financialImpact[key] !== 0)
        : [];

    const plImpacts = getImpacts(plKeys);
    const bsImpacts = getImpacts(bsKeys);
    const notes = financialImpact?.notes;

    return (
        <div className="feedback-display-container">
            <h3>ホストからの評価</h3>
            <p className="comment">{feedback.comment}</p>
            
            {(plImpacts.length > 0 || bsImpacts.length > 0 || notes) && (
                <div className="financial-impact-section">
                    <h4>財務への影響</h4>
                    <div className="impact-grid">
                        {plImpacts.length > 0 && (
                            <div className="impact-category">
                                <h5 className="impact-category-title">損益 (P/L)</h5>
                                <ul className="impact-list">
                                    {plImpacts.map(key => <ImpactItem key={key} impactKey={key} value={financialImpact[key]} />)}
                                </ul>
                            </div>
                        )}
                        
                        {bsImpacts.length > 0 && (
                             <div className="impact-category">
                                <h5 className="impact-category-title">貸借 (B/S)</h5>
                                <ul className="impact-list">
                                    {bsImpacts.map(key => <ImpactItem key={key} impactKey={key} value={financialImpact[key]} />)}
                                </ul>
                            </div>
                        )}
                    </div>
                    
                    {notes && (
                        <div className="impact-notes">
                             <p>
                                <span className="label">備考: </span>
                                <span className="text">{notes}</span>
                             </p>
                        </div>
                    )}
                </div>
            )}

            {!gameEnded && (
                <button 
                    onClick={onNextQuestion} 
                    className="next-question-button"
                >
                    次の質問へ
                </button>
            )}
        </div>
    );
};

export default FeedbackDisplay;