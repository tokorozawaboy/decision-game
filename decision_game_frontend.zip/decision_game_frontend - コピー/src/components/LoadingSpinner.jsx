import React from 'react';
import './LoadingSpinner.css';

const LoadingSpinner = ({ message = "評価を待っています..." }) => (
    <div className="loading-spinner-container">
        <div className="spinner-animation"></div>
        <p className="spinner-message">{message}</p>
    </div>
);

export default LoadingSpinner;