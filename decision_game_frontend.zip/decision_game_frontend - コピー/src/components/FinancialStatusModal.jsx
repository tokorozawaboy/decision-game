// FinancialStatusModal.jsx

import React from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import './FinancialStatusModal.css';

// 数値を読みやすい形式（3桁区切り）にフォーマットする関数
const formatNumber = (num) => num.toLocaleString();

// 勘定科目の行を生成するコンポーネント
const FinancialRow = ({ label, value, isBold = false, isSub = false, isTotal = false }) => (
    <tr className={isTotal ? 'total-row' : ''}>
        <td className={`row-label ${isSub ? 'sub-item' : ''} ${isBold ? 'bold' : ''}`}>
            {label}
        </td>
        <td className={`row-value ${isBold ? 'bold' : ''}`}>
            {formatNumber(value)}
        </td>
    </tr>
);

const FinancialStatusModal = ({ isOpen, onClose, financialData }) => {
    // モーダルが閉じている場合はnullを返す
    if (!isOpen) {
        return null;
    }

    // レンダリング先のDOMノードを取得
    const modalRoot = document.getElementById('modal-root');

    // DOMノードが存在しない場合は、エラーを避けるために何もレンダリングしない
    if (!modalRoot) {
        console.error("モーダルのレンダリング先要素が見つかりません: #modal-root");
        return null; 
    }

    // createPortalを使ってモーダルをレンダリング
    return createPortal(
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="modal-overlay"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0, y: 50 }}
                        animate={{ scale: 1, opacity: 1, y: 0 }}
                        exit={{ scale: 0.9, opacity: 0, y: 50 }}
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                        className="modal-content"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="modal-body">
                            <h3>現在の財務状況</h3>
                            <div className="modal-tables-container">
                                {/* --- 損益計算書 (P/L) --- */}
                                <table className="financial-table">
                                    <thead>
                                        <tr>
                                            <th colSpan="2">損益計算書 (P/L)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <FinancialRow label="売上高" value={financialData.sales} isBold />
                                        <FinancialRow label="売上原価" value={financialData.costOfGoodsSold} isSub />
                                        <FinancialRow label="売上総利益" value={financialData.grossProfitAmount} isBold isTotal />
                                        <FinancialRow label="販売費及び一般管理費" value={financialData.sga} isSub />
                                        <FinancialRow label="営業利益" value={financialData.operatingIncome} isBold isTotal />
                                        <FinancialRow label="営業外収益" value={financialData.nonOperatingIncome} isSub />
                                        <FinancialRow label="営業外費用" value={financialData.nonOperatingExpenses} isSub />
                                        <FinancialRow label="経常利益" value={financialData.ordinaryIncome} isBold isTotal />
                                        <FinancialRow label="法人税等" value={financialData.corporateTax} isSub />
                                        <FinancialRow label="当期純利益" value={financialData.netIncome} isBold isTotal />
                                    </tbody>
                                </table>

                                {/* --- 貸借対照表 (B/S) --- */}
                                <table className="financial-table">
                                    <thead>
                                        <tr>
                                            <th colSpan="2">貸借対照表 (B/S)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <FinancialRow label="流動資産" value={financialData.currentAssets} isSub />
                                        <FinancialRow label="固定資産" value={financialData.fixedAssets} isSub />
                                        <FinancialRow label="資産合計" value={financialData.totalAssets} isBold isTotal />
                                        <FinancialRow label="流動負債" value={financialData.currentLiabilities} isSub />
                                        <FinancialRow label="固定負債" value={financialData.fixedLiabilities} isSub />
                                        <FinancialRow label="負債合計" value={financialData.totalLiabilities} isBold isTotal />
                                        <FinancialRow label="純資産" value={financialData.netAssets} isBold isTotal />
                                        <FinancialRow label="負債・純資産合計" value={financialData.totalLiabilitiesAndNetAssets} isBold isTotal />
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button
                                className="close-button"
                                onClick={onClose}
                            >
                                閉じる
                            </button>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>,
        modalRoot
    );
};

export default FinancialStatusModal;