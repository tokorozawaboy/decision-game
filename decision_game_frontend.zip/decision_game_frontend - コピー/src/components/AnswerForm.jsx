import React, { useState } from 'react';
import './AnswerForm.css';

const AnswerForm = ({ onSubmit, options }) => {
    const [selectedOption, setSelectedOption] = useState('');
    const [reason, setReason] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(selectedOption, reason);
        setSelectedOption('');
        setReason('');
    };

    return (
        <form onSubmit={handleSubmit} className="answer-form">
            <h3>当社の選択</h3>
            <div className="options-container">
                {options.map(option => (
                    <label key={option.id} className="option-label">
                        <input
                            type="radio"
                            name="option"
                            value={option.id}
                            checked={selectedOption === option.id}
                            onChange={(e) => setSelectedOption(e.target.value)}
                            className="option-radio"
                        />
                        <span>{option.text}</span>
                    </label>
                ))}
            </div>
            <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="選択の理由を入力してください..."
                className="reason-textarea"
            ></textarea>
            <button
                type="submit"
                className="submit-answer-button"
                disabled={!selectedOption || !reason}
            >
                回答を送信
            </button>
        </form>
    );
};

export default AnswerForm;