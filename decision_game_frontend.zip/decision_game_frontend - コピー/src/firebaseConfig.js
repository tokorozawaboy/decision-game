import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// .envファイルから環境変数を読み込む
const firebaseConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Firebaseアプリを初期化
const firebaseApp = initializeApp(firebaseConfig);

// Firestoreのインスタンスをエクスポート
export const db = getFirestore(firebaseApp);

// プロジェクトIDもエクスポート
export const app_id = firebaseConfig.projectId;

// 初期財務データもここで定義してエクスポート
export const initialFinancialData = {
    sales: 5_000_000_000, grossProfitAmount: 1_300_000_000, costOfGoodsSold: 3_700_000_000,
    sga: 1_250_000_000, operatingIncome: 50_000_000, nonOperatingIncome: 5_000_000,
    nonOperatingExpenses: 3_000_000, ordinaryIncome: 52_000_000, corporateTax: 15_600_000,
    netIncome: 36_400_000, currentAssets: 800_000_000, fixedAssets: 1_200_000_000,
    totalAssets: 2_000_000_000, currentLiabilities: 500_000_000, fixedLiabilities: 700_000_000,
    totalLiabilities: 1_200_000_000, netAssets: 800_000_000, totalLiabilitiesAndNetAssets: 2_000_000_000
};
