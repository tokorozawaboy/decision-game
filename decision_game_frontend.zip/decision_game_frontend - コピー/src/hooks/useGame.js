import { useState, useEffect, useCallback } from 'react';
import { db, app_id, initialFinancialData } from '../firebaseConfig';
import { doc, getDoc, setDoc, onSnapshot, collection, serverTimestamp } from 'firebase/firestore';

export function useGame() {
    const [userId, setUserId] = useState(null);
    const [allGameContexts, setAllGameContexts] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const [gameState, setGameState] = useState({
        isWaitingForHost: false,
        currentContextData: null,
        gameEnded: false,
        feedback: null,
        answerHistory: [],
        financialData: initialFinancialData,
        financialDataHistory: [initialFinancialData],
        latestFinancialImpactApplied: {},
    });

    // 1. 最初に、ゲームの全シナリオデータを一度だけロード
    useEffect(() => {
        const loadGameContent = async () => {
            try {
                const gameContextsDocRef = doc(db, `artifacts/${app_id}/public/data/game_contexts`, 'all');
                const gameContextsDocSnap = await getDoc(gameContextsDocRef);
                if (gameContextsDocSnap.exists()) {
                    const contexts = gameContextsDocSnap.data().contexts;
                    if (contexts && Object.keys(contexts).length > 0) {
                        setAllGameContexts(contexts);
                    } else {
                        throw new Error('Game scenario data is empty. Please check the CSV file.');
                    }
                } else {
                    throw new Error('Game content not found. Please start the backend server.');
                }
            } catch (err) {
                setError(`Failed to load game content: ${err.message}`);
            } finally {
                setIsLoading(false);
            }
        };
        loadGameContent();
    }, []);

    // 2. ユーザーIDがセットされた後、ユーザーデータをリアルタイムで同期
    useEffect(() => {
        if (!userId || !allGameContexts) return;

        const userDocRef = doc(db, `artifacts/${app_id}/users/${userId}/state`, 'state');
        const unsubscribe = onSnapshot(userDocRef, (userDoc) => {
            if (userDoc.exists()) {
                const userData = userDoc.data();
                const currentPath = userData.currentContextPath;

                setGameState(prev => ({
                    ...prev,
                    currentContextData: allGameContexts[currentPath] || null,
                    answerHistory: userData.answerHistory || [],
                    gameEnded: currentPath === null,
                    financialData: userData.financialData || initialFinancialData,
                    financialDataHistory: userData.financialDataHistory || [initialFinancialData],
                    isWaitingForHost: userData.awaitingHostReview,
                    feedback: userData.latestAnswer ? { comment: userData.latestAnswer.comment } : null,
                    latestFinancialImpactApplied: userData.latestAnswer?.financialImpactApplied || {},
                }));
            } else {
                 setError(`User data for ${userId} not found in database.`);
            }
        }, (err) => {
            setError(`Failed to listen for user data: ${err.message}`);
        });

        return () => unsubscribe();
    }, [userId, allGameContexts]);

    // ログイン処理
    const login = useCallback(async (id) => {
        if (!id || !allGameContexts) return;

        setIsLoading(true);
        setError(null);
        const userDocRef = doc(db, `artifacts/${app_id}/users/${id}/state`, 'state');
        try {
            const userDoc = await getDoc(userDocRef);
            if (!userDoc.exists()) {
                await setDoc(userDocRef, {
                    userId: id,
                    currentContextPath: 'start',
                    answerHistory: [],
                    financialData: initialFinancialData,
                    financialDataHistory: [initialFinancialData],
                    awaitingHostReview: false,
                    latestAnswer: null,
                });
            }
            setUserId(id);
        } catch (err) {
            setError(`Login failed: ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    }, [allGameContexts]);

    // 回答送信処理
    const submitAnswer = useCallback(async (selectedOptionId, reason) => {
        if (!userId || !gameState.currentContextData) return;
        setGameState(prev => ({ ...prev, isWaitingForHost: true }));
        
        // currentContextData.options から selectedOptionId に対応する text を検索
        const currentOptions = gameState.currentContextData.options;
        const selectedOptionObj = currentOptions.find(option => option.id === selectedOptionId);
        // 選択肢テキストが見つからなければ、IDをフォールバックとして使用
        const selectedOptionText = selectedOptionObj ? selectedOptionObj.text : selectedOptionId; //

        const pendingAnswerRef = doc(collection(db, `artifacts/${app_id}/public/data/pending_answers`));
        await setDoc(pendingAnswerRef, {
            userId: userId,
            contextPath: gameState.currentContextData.id,
            selectedOptionId: selectedOptionId,
            selectedOptionText: selectedOptionText, 
            reason: reason,
            timestamp: serverTimestamp(),
            status: 'pending'
        });
        
        const userDocRef = doc(db, `artifacts/${app_id}/users/${userId}/state`, 'state');
        await setDoc(userDocRef, { awaitingHostReview: true }, { merge: true });
    }, [userId, gameState.currentContextData]);

    // 次の質問へ進む処理
    const handleNextQuestion = useCallback(async () => {
        if (!userId) return;
        const userDocRef = doc(db, `artifacts/${app_id}/users/${userId}/state`, 'state');
        await setDoc(userDocRef, { latestAnswer: null }, { merge: true });
    }, [userId]);

    return { userId, isLoading, error, gameState, allGameContexts, login, submitAnswer, handleNextQuestion };
}